import React from 'react';

function Recent() {
    return (
        <div>
            <p>
                최근 검색어
            </p>
            <div>
                <p>
                    새우두부
                </p>
            </div>
        </div>
    );
}

export default Recent;