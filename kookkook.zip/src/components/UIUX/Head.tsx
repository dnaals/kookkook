//헤더메뉴
import React from 'react';
import "../style/header_footer.scss";

function Head() {
    return (
        <div className='head'>
            <h1>Kook Kook</h1>
        </div>
    );
}

export default Head;