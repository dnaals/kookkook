import React from 'react';

function Search() {
    return (
        <div>
            <form>
                <input type='text' placeholder='레시피 키워드를 입력하세요!'></input>
            </form>
        </div>
    );
}

export default Search;