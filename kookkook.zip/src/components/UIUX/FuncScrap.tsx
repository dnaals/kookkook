//스크랩버튼 기능

import React from 'react';
import "@/components/style/scrap.scss";

function FuncScrap() {
    return (
        <div className="scrap">
            <button><img src="/images/bookmark_before.png" /></button>
        </div>
    );
}

export default FuncScrap;