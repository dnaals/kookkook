export type initTy = {
    seq?:number;
    name?:string;
    m_cate?:string;
    s_cate?:string;
    ingredient?: string;
    tip?: string;
    MANUAL01?: string;
    MANUAL_IMG01?: string;
    HASH_TAG?: string;
    s_thumb?: string;
    m_thumb?: string;
    like?: number;
}

export type initTy1 = {
    user?:string;
    email?:string
}