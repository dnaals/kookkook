import React from 'react';

function page() {
    return (
        <div>
            검색 상세
        </div>
    );
}

export default page;