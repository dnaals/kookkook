import RecipeSq from '@/components/UIUX/RecipeSq';
import Search from '@/components/UIUX/Search';
import React from 'react';

function page() {
    return (
        <div>
            
        </div>
    );
}

export default page;