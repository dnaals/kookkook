import React from 'react';
function page() {
    return (
        <div>
            마이페이지
        </div>
    );
}

export default page;